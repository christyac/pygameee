Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - DaveJf ( https://freesound.org/people/DaveJf/ )

You can find this pack online at: https://freesound.org/people/DaveJf/packs/30146/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 534879__davejf__deep-bass-01.mp3
    * url: https://freesound.org/s/534879/
    * license: Creative Commons 0


